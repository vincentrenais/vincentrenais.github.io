@import UIKit;

//! Project version number for InteracProximitySDK.
FOUNDATION_EXPORT double InteracProximitySDKVersionNumber;

//! Project version string for InteracProximitySDK.
FOUNDATION_EXPORT const unsigned char InteracProximitySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import
// <InteracProximitySDK/PublicHeader.h>

#import <InteracProximitySDK/INPBLEManager.h>
