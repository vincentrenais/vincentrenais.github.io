#import <Foundation/Foundation.h>
#import <CoreBluetooth/CoreBluetooth.h>

NS_ASSUME_NONNULL_BEGIN

@class INPBLEManager;

@protocol INPBLEManagerDelegate <NSObject>

- (void)BLEManager:(INPBLEManager *)manager didDiscoverDevices:(NSArray *)devices;
- (void)BLEManager:(INPBLEManager *)manager didEncouterErrorWithState:(CBManagerState)state;

@end

@interface INPBLEManager : NSObject <CBPeripheralManagerDelegate, CBCentralManagerDelegate>

@property (nonatomic, weak) id<INPBLEManagerDelegate> delegate;

- (instancetype)initWithIdentifier:(NSString *)userIdentifier;

@end

NS_ASSUME_NONNULL_END
